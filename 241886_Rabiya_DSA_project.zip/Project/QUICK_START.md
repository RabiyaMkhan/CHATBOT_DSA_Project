# Quick Start Guide

## 🚀 Get Started in 5 Minutes

### Step 1: Setup Firebase (2 minutes)

1. Go to [Firebase Console](https://console.firebase.google.com/)
2. Create a new project
3. Enable **Realtime Database**
4. Copy your Database URL and API Key

### Step 2: Configure Server (1 minute)

Edit `config.txt`:
```
FIREBASE_URL=https://your-project.firebaseio.com
FIREBASE_KEY=your-api-key-here
PORT=8080
```

### Step 3: Build Server (1 minute)

**Windows:**
```bash
g++ -std=c++11 -o chatbot_server.exe server_main.cpp APIServer.cpp FirebaseClient.cpp Chatbot.cpp LinkedList.cpp Queue.cpp Stack.cpp HashMap.cpp -lcurl -lws2_32
```

**Linux:**
```bash
g++ -std=c++11 -o chatbot_server server_main.cpp APIServer.cpp FirebaseClient.cpp Chatbot.cpp LinkedList.cpp Queue.cpp Stack.cpp HashMap.cpp -lcurl -lpthread
```

**Mac:**
```bash
g++ -std=c++11 -o chatbot_server server_main.cpp APIServer.cpp FirebaseClient.cpp Chatbot.cpp LinkedList.cpp Queue.cpp Stack.cpp HashMap.cpp -lcurl
```

### Step 4: Run Server (30 seconds)

```bash
./chatbot_server    # Linux/Mac
chatbot_server.exe  # Windows
```

You should see:
```
Server listening on port 8080
```

### Step 5: Setup Flutter App (1 minute)

1. Create Flutter project:
```bash
flutter create chatbot_flutter
cd chatbot_flutter
```

2. Copy files:
   - Copy `flutter/lib/services/chatbot_service.dart` to `lib/services/`
   - Copy `flutter/lib/screens/chat_screen.dart` to `lib/screens/`
   - Copy `flutter/lib/main.dart` to `lib/main.dart`

3. Add dependency:
```yaml
# pubspec.yaml
dependencies:
  http: ^0.13.5
```

4. Update server URL in `lib/services/chatbot_service.dart`:
```dart
ChatbotService({this.baseUrl = 'http://YOUR_IP:8080'})
```

5. Run:
```bash
flutter pub get
flutter run
```

## ✅ Test It Works

### Test Server:
```bash
curl http://localhost:8080/api/health
```

Should return:
```json
{"success":true,"message":"Server is healthy",...}
```

### Test Chat:
```bash
curl -X POST http://localhost:8080/api/chat \
  -H "Content-Type: application/json" \
  -H "X-User-Id: test123" \
  -d '{"message":"Hello"}'
```

## 📱 Flutter App Usage

1. Open the app
2. Enter a user ID (e.g., "user123")
3. Start chatting!

## 🔧 Troubleshooting

**Server won't start?**
- Check if port 8080 is free
- Install libcurl: `sudo apt-get install libcurl4-openssl-dev` (Linux)

**Flutter can't connect?**
- Use your computer's IP, not localhost
- For Android emulator: use `10.0.2.2:8080`
- Check firewall settings

**Firebase errors?**
- Verify URL and API key in config.txt
- Check Realtime Database is enabled
- Update database rules to allow read/write

## 📚 Next Steps

- Read `SETUP_GUIDE.md` for detailed setup
- Read `README_API.md` for API documentation
- Customize responses in `Chatbot.cpp`
- Add authentication
- Deploy to cloud

## 🎯 Project Structure

```
Project/
├── C++ Server Files
│   ├── server_main.cpp      # HTTP server entry point
│   ├── APIServer.h/cpp      # REST API implementation
│   ├── FirebaseClient.h/cpp # Firebase integration
│   └── [DSA files...]       # Chatbot with DSA
│
├── Flutter App
│   ├── lib/
│   │   ├── main.dart        # App entry point
│   │   ├── services/        # API service
│   │   └── screens/         # UI screens
│   └── pubspec.yaml
│
└── Config
    └── config.txt           # Firebase configuration
```

Happy coding! 🚀

