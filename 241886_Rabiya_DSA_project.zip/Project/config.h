#ifndef CONFIG_H
#define CONFIG_H

#include <string>

// Guardian API
const std::string GUARDIAN_API_KEY = "a0b5386d-4cd2-48b4-a86f-356a336f112e";

// Firebase Configuration - ⭐ REPLACE WITH YOUR FIREBASE URL
const std::string FIREBASE_URL = "https://chatbot-cec24-default-rtdb.asia-southeast1.firebasedatabase.app";

#endif